package OmniVision_pkg

const A = 1792
const B = 1198
const C = 687
const D = 390
const E = 233
const F = 75
const G = 73
const H = 400
const I = 360
const J = 30
const K = 12
const L = 100
const M = 100
const N = 6
const O = 100
const P = 50
const Q = 300
