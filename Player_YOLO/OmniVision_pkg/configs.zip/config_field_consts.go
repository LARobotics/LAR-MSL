package OmniVision_pkg

const A = 1800
const B = 1200
const C = 650
const D = 350
const E = 225
const F = 75
const G = 75
const H = 400
const I = 300
const J = 15
const K = 10
const L = 100
const M = 100
const N = 6
const O = 100
const P = 50
const Q = 300
